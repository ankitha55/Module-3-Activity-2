
// any statement that starts with // is a comment
// comments are ignored by the compiler
// comments are used to explain the code

// this is a class
// a class is a blueprint for an object
// an object is an instance of a class
// a class can have many objects
// a class can have many methods
// a class can have many fields
// a class can have many constructors


// Scanner is a class in the java.util package
// the java.util package contains many useful classes
// the java.util package is required to read input from the user
// import is a keyword used to import a class from a library
import java.util.Scanner;
// in the text based UI. 
// The Scanner class is used to read input from the user
// using keyboard in the console

// this is a class and is named App. It has to be the same as the file name
public class App {
  
    // main is the name of the method
    // main is the entry point of the program
    // main is the first method that is executed when the program is run
    // main is a special method
    // main is a static method
    // static means that the method belongs to the class and not to an object
    // static methods can be called without creating an object
    // static methods can be called using the class name
    // static methods can be called using the class name and the dot operator
    // run | debug | debug 'App.main()' to run the program
    // this is called the hot menu in VS Code
    public static void main(String[] args) {
        // this is a statement
        // System is a class in the java.lang package
        // the java.lang package is automatically imported
        Scanner scanner = new Scanner(System.in);

        // System.out.println prints a line to the console
        // System.out.print prints to the console without a new line
        // With or without a prompt message, the program will wait for the user to enter a number
        System.out.print("Enter a number: ");
        // scanner.nextInt() reads an integer from the user
        // the value is stored in the variable number
        // since prompt is asking for a number, the user will enter a number
        // as scanner.nextInt() is expecting an integer, the user will enter an integer
        long number = scanner.nextLong();

        // Integer.toBinaryString converts an integer to a binary string
        // Integer.toBinaryString is a static method
        // Integer.toBinaryString is a method of the Integer class

        String binary = Long.toBinaryString(number);
        // print the binary string
        System.out.println("Binary: " + binary);

        // scanner.close() closes the scanner
        // close the scanner
        scanner.close();

        // Scanner class allows you to read stream of characters from the user 
        // and convert it to string data type
        // It is like collecting water from a tap
        // a good programmer will close the tap after collecting the water
    }
}
